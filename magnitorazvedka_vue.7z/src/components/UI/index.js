import CustomTextInput from '@/components/UI/CustomTextInput';
import CustomButton from '@/components/UI/CustomButton';
import CustomSelect from '@/components/UI/CustomSelect';

export default [
    CustomTextInput,
    CustomButton,
    CustomSelect,
];