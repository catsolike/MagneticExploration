<template>

    <input  class="input-text" type="text">
    
</template>

<script>

export default {
    name: 'custom-text-input',
    props:{

    },
    methods:{
        
    }
}
</script>

<style lang="scss" scoped>
.input-text {
    width: 100%;
    padding: 10px 15px;
    background: $input-background;
    border-radius: 3px;
}

</style>